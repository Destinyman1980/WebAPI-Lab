const config = {
    host: "localhost",
    port: 5432,
    user: "postgres",
    password: "your_password", //Update this parameter
    database: "your_database", //Update this parameter
    connection_limit:100
}

export default config;