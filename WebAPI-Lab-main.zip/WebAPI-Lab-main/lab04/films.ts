const films = [
    {
        id: 1,
        title: "About Time",
        duration: 120
      },
    {
      id: 2,
      title: "Star War",
      duration: 100
    }
  ]

export default films;